
exports.now = function () {
  // return new Date(Date.now()).toLocaleString();
  return new Date().toISOString();

}
