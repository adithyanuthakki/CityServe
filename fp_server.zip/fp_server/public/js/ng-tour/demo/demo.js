
var app = angular.module('myApp', [
	'ui.bootstrap',
	'ngTour'
]);

app.controller('myController', function ($scope) {



});