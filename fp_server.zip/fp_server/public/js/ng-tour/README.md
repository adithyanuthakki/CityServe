ngTour
==============

License: MIT

A tour directive to provide your users a tour of the different key-features of your page

Example
-------

Check out [http://hanselsen.github.io/ngTour/](http://hanselsen.github.io/ngTour/)  
  
Check out the files in the demo folder for usage.  

Install
-------

#### With bower:

    $ bower install ng-tour
