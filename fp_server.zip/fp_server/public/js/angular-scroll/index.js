require('angular');
require('./angular-scroll');

module.exports = 'duScroll';
