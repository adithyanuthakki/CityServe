Store installation files here. See LIQUIBASE_HOME/README.txt for more information
