export const environment = {
    production: true,
    apiUrl: 'http://35.196.225.9:1337'
};
