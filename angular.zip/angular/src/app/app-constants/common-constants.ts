export class AppConstants {}
